# Centro de control de Mariscos Luse

Acceso: https://mariscos-luse.pages.dev/?access=tech . Iniciar sesión con el correo Tech autorizado. Administrador continúa sin usuario asignado.

## Qué permite

- Panorama visual por últimos 7 días, 30 días o todo el historial: ventas netas, utilidad bruta, gastos y resultado operativo estimado.
- Productos y precios: crear productos, editar nombre/categoría/precio/mínimo, ocultar o activar productos; historial de cambios de precio.
- Ítems de costo por producto: agregar varios conceptos como empaque, hielo, transporte o preparación, expresados en COP por kg o unidad. Permite retirar un ítem; no altera ventas históricas.
- Inventario: entradas por proveedor/lote y fecha, cantidad bruta comprada, cantidad neta aprovechable, valor total de compra, mermas y ajustes positivos o negativos con motivo. No permite existencias negativas.
- Ventas: registrar ventas realizadas con cantidad, precio, descuento y fecha. Descuenta stock y conserva una copia de precio y costo del momento.
- Gastos generales: registrar concepto, monto y fecha. Exportar ventas a CSV del período seleccionado en el dashboard.
- Catálogo público conectado a precios y disponibilidad compartidos, actualización al volver a la tienda o en hasta 30 segundos.

## Cómo empezar

1. Recuperar contraseña si hace falta, usando el enlace del formulario Tech. Revisar spam. Abrir el enlace recibido y definir personalmente la nueva contraseña.
2. En Inventario, elegir Entrada / lote, producto, cantidades bruta y aprovechable y valor de compra.
3. En Productos y precios, ajustar precio y agregar los ítems adicionales por kg o unidad.
4. Registrar ventas realizadas y gastos para alimentar el dashboard.

No hay cantidades de prueba en el inventario: todos los productos comenzaron en cero. Los precios iniciales siguen siendo de referencia y deben reemplazarse por los reales. Los productos sin existencias se muestran agotados.

## Cálculos

- Compra aprovechable de un lote = costo total bruto / cantidad neta aprovechable.
- Costo de compra del producto = promedio ponderado por cantidad de los lotes disponibles al entrar mercancía.
- Costo unitario de venta = compra promedio + suma de ítems de costo por kg o unidad.
- Ventas netas = cantidades × precio de venta − descuentos.
- Utilidad bruta = ventas netas − costo histórico de lo vendido.
- Resultado operativo estimado = utilidad bruta − gastos generales − valor de mermas y ajustes negativos a costo de compra.
- Rentabilidad potencial = (precio actual − costo unitario actual) / precio actual. No es utilidad realizada. Si falta registrar compra, el tablero lo indica.

Ejemplo: 10 kg brutos comprados por $200.000; 8 kg aprovechables. Compra aprovechable $25.000/kg. Si empaque e hielo cuestan $2.000/kg y se vende a $40.000/kg, utilidad bruta potencial $13.000/kg, margen 32,5 %.

La limpieza ya excluida de la cantidad aprovechable NO debe ingresarse como otra merma: duplicaría la pérdida. Los costos adicionales asociados a ventas no deben repetirse como gastos generales si se quiere evitar contarlos dos veces.

## Límites de esta fase

- Los pedidos del carrito siguen siendo de prueba locales; no se convierten automáticamente en ventas ni reservas de inventario. Solo registrar ventas efectivamente realizadas en el panel.
- El resultado depende de todos los datos registrados; no incluye impuestos, obligaciones contables ni gastos omitidos.
- Los movimientos conservan referencia de lote, sin seguimiento FIFO ni saldo individual por lote. El costeo es promedio ponderado por producto.
- No hay todavía anulación/edición de ventas registradas, edición de gastos, devoluciones, sustituciones o reportes contables. Los ajustes de stock no corrigen una venta histórica.
- La gestión muestra hasta 10.000 filas por tabla y avisa si se alcanza el límite. Movimientos visibles: últimos 100; precios: últimos 50.
- Al crear productos nuevos se utiliza imagen de referencia genérica; carga de fotos reales y presentaciones editables quedan para una siguiente fase.

## Verificación

Ocho pruebas locales correctas y compilación. Prueba transaccional en Supabase verificó costo por rendimiento, snapshot de costos, stock después de venta y merma, bloqueo de sobreventa y aislamiento para usuario sin rol. Toda esa prueba se revirtió y no dejó datos ficticios.

Las consultas anónimas a productos internos, costos, ventas y movimientos devolvieron HTTP 401. El catálogo público expone solamente información comercial y disponibilidad, sin costos internos.

Pendiente verificación visual y de interacción con la sesión Tech del propietario después de recuperar contraseña. No se han leído ni generado contraseñas del propietario.

Revisión visual local completada con datos ficticios separados de Supabase: dashboard, lista de precios y formulario con múltiples ítems de costo. Se corrigió el contraste del encabezado. La recuperación por correo está publicada y el propietario solicitó el enlace desde la interfaz; aún falta que complete el cambio de contraseña para validar su sesión real.
