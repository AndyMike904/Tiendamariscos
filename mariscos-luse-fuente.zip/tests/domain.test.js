import test from 'node:test';
import assert from 'node:assert/strict';
import {products,total,message} from '../src/domain.js';
test('catálogo inicial de diez productos con identificadores únicos',()=>{assert.equal(products.length,10);assert.equal(new Set(products.map(p=>p.id)).size,10)});
test('total con peso fraccionario y unidad',()=>assert.equal(total([{price:62000,quantity:.75},{price:8000,quantity:6}]),94500));
test('mensaje conserva cortes, número y entrega',()=>{const m=message({name:'Cliente',number:'0001',items:[{name:'Pargo',presentation:'Filete',quantity:.5,unit:'kg',price:42000,note:'Sin espinas'}],delivery:'Domicilio',date:'2026-10-20',slot:'Mañana',address:'Buenaventura'});assert.match(m,/#0001/);assert.match(m,/Sin espinas/);assert.match(m,/Buenaventura/);assert.ok(m.length<1500)});
