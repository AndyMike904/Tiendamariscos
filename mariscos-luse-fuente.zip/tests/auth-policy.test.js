import test from 'node:test';
import assert from 'node:assert/strict';
import {canAccess} from '../src/auth-policy.js';
test('solo el rol explícito y activo concede su sección',()=>{
 assert.equal(canAccess([{role:'admin',active:true}],'admin'),true);
 assert.equal(canAccess([{role:'admin',active:true}],'tech'),false);
 assert.equal(canAccess([{role:'tech',active:true}],'admin'),false);
 assert.equal(canAccess([{role:'tech',active:true}],'tech'),true);
});
test('sin roles, inactivo, desconocido o datos alterados se deniega',()=>{
 for(const roles of [null,[],[{role:'admin',active:false}],[{role:'admin',active:'true'}],[{role:'superadmin',active:true}]])assert.equal(canAccess(roles,'admin'),false);
 assert.equal(canAccess([{role:'admin',active:true}],'unknown'),false);
});
