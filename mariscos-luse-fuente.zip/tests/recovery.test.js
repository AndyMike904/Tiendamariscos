import test from 'node:test';
import assert from 'node:assert/strict';
import {recoveryFeedback,isRecoveryFragment} from '../src/auth-recovery.js';
test('límite de correo nunca se anuncia como envío exitoso',()=>{const r=recoveryFeedback({status:429,code:'over_email_send_rate_limit'});assert.match(r.message,/No se envió/);assert.equal(r.wait,3600)});
test('solicitud aceptada conserva mensaje genérico y pausa',()=>{assert.equal(recoveryFeedback(null).wait,60);assert.match(recoveryFeedback(null).message,/Si el correo/)});
test('enlace de recuperación se reconoce antes de que el cliente limpie la URL',()=>{assert.equal(isRecoveryFragment('#access_token=ejemplo&type=recovery'),true);assert.equal(isRecoveryFragment('#access_token=ejemplo&type=invite'),false)});
