import test from 'node:test';
import assert from 'node:assert/strict';
import {financials,unitEconomics,csvCell} from '../src/business-domain.js';
test('ventas fraccionarias: bruto, descuento, costo histórico, gastos y mermas',()=>{
 const f=financials([{quantity:.75,unit_price:60000,unit_cost:32000,discount_cop:5000}],[{amount_cop:3000}],2000);
 assert.deepEqual(f,{gross:45000,discounts:5000,revenue:40000,cogs:24000,overhead:3000,profit:16000,net:11000,losses:2000,margin:40});
});
test('el costo por producto incluye solo sus ítems y admite pérdidas',()=>{
 const f=unitEconomics({id:'p',purchase_cost:50000,price_cop:45000},[{product_id:'p',amount_cop:2000},{product_id:'otro',amount_cop:99999}]);
 assert.equal(f.cost,52000);assert.equal(f.profit,-7000);assert.ok(f.margin<0);
});
test('sin ventas no se inventa margen; CSV protege fórmulas',()=>{assert.equal(financials([],[]).margin,null);assert.equal(csvCell('=SUM(A1)'),"\"'=SUM(A1)\"")});
