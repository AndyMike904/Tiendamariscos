-- Fase de autenticación del equipo. No crea permisos sobre pedidos o productos.
-- Ejecutar en SQL Editor del proyecto como propietario, antes de activar el cliente.
begin;
create table if not exists public.staff_roles (
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null check (role in ('admin','tech')),
 active boolean not null default true,
 created_at timestamptz not null default now(),
 primary key (user_id, role)
);
alter table public.staff_roles enable row level security;
revoke all on public.staff_roles from anon, authenticated;
grant select on public.staff_roles to authenticated;
drop policy if exists staff_read_own_roles on public.staff_roles;
create policy staff_read_own_roles on public.staff_roles
 for select to authenticated using ((select auth.uid()) = user_id);
-- Sin políticas INSERT/UPDATE/DELETE para clientes. Solo el operador de la base
-- puede asignar/revocar roles. No confiar en user_metadata ni en localStorage.
commit;

-- Asignación manual posterior, con UUID real de un usuario creado en Auth.
-- No ejecutar sin autorización del propietario para esa cuenta y ese rol:
-- insert into public.staff_roles(user_id,role) values ('UUID_CONFIRMADO','admin');
-- insert into public.staff_roles(user_id,role) values ('UUID_CONFIRMADO','tech');
-- Revocar inmediatamente mediante active=false en SQL Editor.
