-- Gestión comercial: inventario compartido, costos y ventas registradas.
begin;
create or replace function public.luse_staff() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.staff_roles where user_id=auth.uid() and active and role in ('tech','admin'));
$$;
revoke all on function public.luse_staff() from public;
grant execute on function public.luse_staff() to authenticated;
create table public.business_products (
 id text primary key, name text not null check(length(name) between 1 and 100), category text not null check(category in ('Pescados','Mariscos','Moluscos')),
 unit text not null check(unit in ('kg','unidad')), price_cop numeric(14,0) not null check(price_cop>=0),
 purchase_cost numeric(14,2) not null default 0 check(purchase_cost>=0), stock numeric(14,3) not null default 0 check(stock>=0),
 stock_min numeric(14,3) not null default 3 check(stock_min>=0), active boolean not null default true,
 photo text not null default '', origin text not null default '', presentations text[] not null default array['Estándar'],
 updated_at timestamptz not null default now()
);
create table public.product_costs (
 id uuid primary key default gen_random_uuid(), product_id text not null references public.business_products(id),
 label text not null check(length(label) between 1 and 100), amount_cop numeric(14,0) not null check(amount_cop>=0)
);
create table public.stock_moves (
 id uuid primary key default gen_random_uuid(), product_id text not null references public.business_products(id),
 kind text not null check(kind in ('entrada','merma','ajuste','venta')), quantity numeric(14,3) not null check(quantity<>0),
 loss_cost numeric(14,2) not null default 0, gross_quantity numeric(14,3), purchase_total numeric(14,0), supplier text not null default '', note text not null,
 lot text not null default '', received_on date, created_at timestamptz not null default now(), created_by uuid not null references auth.users(id)
);
create table public.business_sales (
 id uuid primary key default gen_random_uuid(), product_id text not null references public.business_products(id),
 quantity numeric(14,3) not null check(quantity>0), unit_price numeric(14,0) not null check(unit_price>=0),
 unit_cost numeric(14,2) not null check(unit_cost>=0), discount_cop numeric(14,0) not null default 0 check(discount_cop>=0),
 sold_on date not null, note text not null default '', created_at timestamptz not null default now(), created_by uuid not null references auth.users(id)
);
create table public.business_expenses (
 id uuid primary key default gen_random_uuid(), label text not null check(length(label) between 1 and 100),
 amount_cop numeric(14,0) not null check(amount_cop>0), spent_on date not null, created_at timestamptz not null default now(), created_by uuid not null default auth.uid() references auth.users(id)
);
create table public.price_events (
 id uuid primary key default gen_random_uuid(), product_id text not null references public.business_products(id),
 previous_price numeric(14,0), new_price numeric(14,0), created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
alter table public.business_products enable row level security;
alter table public.product_costs enable row level security;
alter table public.stock_moves enable row level security;
alter table public.business_sales enable row level security;
alter table public.business_expenses enable row level security;
alter table public.price_events enable row level security;
revoke all on public.business_products,public.product_costs,public.stock_moves,public.business_sales,public.business_expenses,public.price_events from anon,authenticated;
grant select on public.business_products,public.product_costs,public.stock_moves,public.business_sales,public.business_expenses,public.price_events to authenticated;
grant insert,update on public.product_costs,public.business_expenses to authenticated;
grant delete on public.product_costs to authenticated;
create policy products_staff_read on public.business_products for select to authenticated using (public.luse_staff());
create policy costs_staff_all on public.product_costs for all to authenticated using (public.luse_staff()) with check (public.luse_staff());
create policy moves_staff_read on public.stock_moves for select to authenticated using (public.luse_staff());
create policy sales_staff_read on public.business_sales for select to authenticated using (public.luse_staff());
create policy expenses_staff_all on public.business_expenses for all to authenticated using (public.luse_staff()) with check (public.luse_staff() and created_by=auth.uid());
create policy prices_staff_read on public.price_events for select to authenticated using (public.luse_staff());
create or replace function public.luse_product(p_id text,p_name text,p_category text,p_unit text,p_price numeric,p_min numeric,p_active boolean) returns void
language plpgsql security definer set search_path=public as $$
declare old_price numeric; old_unit text;
begin
 if not public.luse_staff() then raise exception 'Acceso denegado'; end if;
 if p_price is null or p_price<0 or p_price<>trunc(p_price) or p_min is null or p_min<0 then raise exception 'Precio o mínimo inválido';end if;
 select price_cop,unit into old_price,old_unit from business_products where id=p_id for update;
 if found and old_unit<>p_unit then raise exception 'No se puede cambiar la unidad de un producto existente';end if;
 insert into business_products(id,name,category,unit,price_cop,stock_min,active) values(p_id,trim(p_name),p_category,p_unit,p_price,p_min,p_active)
 on conflict(id) do update set name=excluded.name,category=excluded.category,price_cop=excluded.price_cop,stock_min=excluded.stock_min,active=excluded.active,updated_at=now();
 if old_price is distinct from p_price then insert into price_events(product_id,previous_price,new_price,created_by) values(p_id,old_price,p_price,auth.uid());end if;
end;$$;
create or replace function public.luse_move(p_product text,p_kind text,p_quantity numeric,p_gross numeric,p_total numeric,p_supplier text,p_note text,p_lot text,p_date date) returns void
language plpgsql security definer set search_path=public as $$
declare p business_products%rowtype; next_stock numeric; next_cost numeric;
begin
 if not public.luse_staff() then raise exception 'Acceso denegado';end if;
 select * into p from business_products where id=p_product for update;
 if not found then raise exception 'Producto no encontrado';end if;
 if p_kind not in ('entrada','merma','ajuste') or p_quantity is null or p_quantity=0 or p_quantity<>round(p_quantity,3) or length(trim(p_note))<3 then raise exception 'Movimiento o motivo inválido';end if;
 if p.unit='unidad' and p_quantity<>trunc(p_quantity) then raise exception 'Las unidades deben ser enteras';end if;
 if (p_kind='entrada' and p_quantity<=0) or (p_kind='merma' and p_quantity>=0) then raise exception 'Signo de cantidad inválido';end if;
 next_stock=p.stock+p_quantity;
 if next_stock<0 then raise exception 'Inventario insuficiente';end if;
 next_cost=p.purchase_cost;
 if p_kind='entrada' then
 if p_gross is null or p_gross<p_quantity or p_total is null or p_total<0 or p_total<>trunc(p_total) or p_date is null then raise exception 'Compra bruta, valor o fecha inválidos';end if;
 next_cost=(p.stock*p.purchase_cost+p_total)/next_stock;
 end if;
 update business_products set stock=next_stock,purchase_cost=next_cost,updated_at=now() where id=p_product;
 insert into stock_moves(product_id,kind,quantity,loss_cost,gross_quantity,purchase_total,supplier,note,lot,received_on,created_by)
 values(p_product,p_kind,p_quantity,case when p_quantity<0 then -p_quantity*p.purchase_cost else 0 end,case when p_kind='entrada' then p_gross end,case when p_kind='entrada' then p_total end,left(coalesce(p_supplier,''),120),left(p_note,300),left(coalesce(p_lot,''),100),p_date,auth.uid());
end;$$;
create or replace function public.luse_sale(p_product text,p_quantity numeric,p_price numeric,p_discount numeric,p_date date,p_note text) returns void
language plpgsql security definer set search_path=public as $$
declare p business_products%rowtype; extras numeric;
begin
 if not public.luse_staff() then raise exception 'Acceso denegado';end if;
 select * into p from business_products where id=p_product for update;
 if not found or not p.active then raise exception 'Producto no disponible';end if;
 if p_quantity is null or p_quantity<=0 or p_quantity>p.stock or p_quantity<>round(p_quantity,3) or (p.unit='unidad' and p_quantity<>trunc(p_quantity)) then raise exception 'Cantidad inválida o inventario insuficiente';end if;
 if p_price is null or p_price<0 or p_price<>trunc(p_price) or p_discount is null or p_discount<0 or p_discount>round(p_quantity*p_price) or p_discount<>trunc(p_discount) or p_date is null then raise exception 'Valor o fecha inválidos';end if;
 select coalesce(sum(amount_cop),0) into extras from product_costs where product_id=p_product;
 insert into business_sales(product_id,quantity,unit_price,unit_cost,discount_cop,sold_on,note,created_by)
 values(p_product,p_quantity,p_price,p.purchase_cost+extras,p_discount,p_date,left(coalesce(p_note,''),300),auth.uid());
 update business_products set stock=stock-p_quantity,updated_at=now() where id=p_product;
 insert into stock_moves(product_id,kind,quantity,note,created_by) values(p_product,'venta',-p_quantity,'Venta registrada',auth.uid());
end;$$;
create or replace function public.luse_catalog() returns table(id text,name text,category text,unit text,price numeric,stock numeric,photo text,origin text,presentations text[])
language sql stable security definer set search_path=public as $$
 select id,name,category,unit,price_cop,stock,photo,origin,presentations from business_products where active;
$$;
revoke all on function public.luse_product(text,text,text,text,numeric,numeric,boolean),public.luse_move(text,text,numeric,numeric,numeric,text,text,text,date),public.luse_sale(text,numeric,numeric,numeric,date,text),public.luse_catalog() from public;
grant execute on function public.luse_product(text,text,text,text,numeric,numeric,boolean),public.luse_move(text,text,numeric,numeric,numeric,text,text,text,date),public.luse_sale(text,numeric,numeric,numeric,date,text) to authenticated;
grant execute on function public.luse_catalog() to anon,authenticated;
commit;

insert into public.business_products(id,name,category,unit,price_cop,photo,origin,presentations) values
('salmon','Salmón','Pescados','kg',78000,'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=640&q=75','Chile',array['Filete','Lomo','Porciones']),
('trucha','Trucha','Pescados','kg',32000,'https://images.unsplash.com/photo-1510130387422-82bed34b37e9?auto=format&fit=crop&w=640&q=75','Colombia',array['Entera','Filete']),
('pargo','Pargo rojo','Pescados','kg',42000,'https://images.unsplash.com/photo-1535399831218-d5bd36d1a6b3?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Entero limpio','Filete']),
('robalo','Róbalo','Pescados','kg',48000,'https://images.unsplash.com/photo-1510130387422-82bed34b37e9?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Postas','Filete']),
('corvina','Corvina','Pescados','kg',45000,'https://images.unsplash.com/photo-1535399831218-d5bd36d1a6b3?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Filete','Postas']),
('atun','Atún','Pescados','kg',65000,'https://images.unsplash.com/photo-1510130387422-82bed34b37e9?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Lomo','Bloque']),
('camaron','Camarón tigre','Mariscos','kg',62000,'https://images.unsplash.com/photo-1625944525533-473f1a3d54e7?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Pelado','Con cáscara']),
('langostino','Langostino','Mariscos','kg',72000,'https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Mediano','Jumbo']),
('pulpo','Pulpo','Moluscos','kg',68000,'https://images.unsplash.com/photo-1544943910-4c1dc44aab44?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Entero','Tentáculos']),
('ostras','Ostras','Moluscos','unidad',8000,'https://images.unsplash.com/photo-1559737558-2f5a35f4523b?auto=format&fit=crop&w=640&q=75','Pacífico colombiano',array['Unidad'])
on conflict(id) do nothing;
