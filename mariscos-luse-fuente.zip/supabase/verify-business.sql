-- Verificación reversible. No deja productos, ventas ni existencias de prueba.
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub','aa1763eb-12ca-4d50-b473-c4b3510fb4c5',true);
select public.luse_product('__luse_test__','Prueba transaccional','Pescados','kg',30,1,true);
select public.luse_move('__luse_test__','entrada',8,10,100,'Prueba','Entrada de prueba','TEST',current_date);
insert into public.product_costs(product_id,label,amount_cop) values('__luse_test__','Empaque prueba',3);
select public.luse_sale('__luse_test__',2,30,0,current_date,'Venta de prueba reversible');
select public.luse_move('__luse_test__','merma',-1,null,null,'','Merma de prueba','',current_date);
do $$declare n numeric; c numeric; sale_cost numeric; denied boolean:=false;
begin
 select stock,purchase_cost into n,c from public.business_products where id='__luse_test__';
 if n<>5 or c<>12.5 then raise exception 'Fallo stock/costo: % %',n,c;end if;
 select unit_cost into sale_cost from public.business_sales where product_id='__luse_test__';
 if sale_cost<>15.5 then raise exception 'Fallo snapshot costo';end if;
 begin perform public.luse_sale('__luse_test__',99,30,0,current_date,'Sobreventa');exception when others then denied:=true;end;
 if not denied then raise exception 'Se permitió sobreventa';end if;
end $$;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
do $$declare n integer; denied boolean:=false;begin
 select count(*) into n from public.business_products;
 if n<>0 then raise exception 'Usuario sin rol lee datos';end if;
 begin perform public.luse_product('__forbidden__','No autorizado','Pescados','kg',1,0,true);exception when others then denied:=true;end;
 if not denied then raise exception 'Usuario sin rol escribe datos';end if;
end $$;
rollback;
select 'PASS: costos, ventas, merma, sobreventa y aislamiento; sin datos de prueba guardados' as resultado;
