export function unitEconomics(product,costs){
 const extra=costs.filter(c=>c.product_id===product.id).reduce((n,c)=>n+Number(c.amount_cop),0);
 const cost=Number(product.purchase_cost)+extra;
 const profit=Number(product.price_cop)-cost;
 return {cost,extra,profit,margin:Number(product.price_cop)>0?profit/Number(product.price_cop)*100:null};
}
export function financials(sales,expenses,losses=0){
 const gross=sales.reduce((n,s)=>n+Math.round(Number(s.quantity)*Number(s.unit_price)),0);
 const discounts=sales.reduce((n,s)=>n+Number(s.discount_cop),0);
 const cogs=sales.reduce((n,s)=>n+Math.round(Number(s.quantity)*Number(s.unit_cost)),0);
 const overhead=expenses.reduce((n,e)=>n+Number(e.amount_cop),0);
 const revenue=gross-discounts,profit=revenue-cogs;
 return {gross,discounts,revenue,cogs,overhead,profit,net:profit-overhead-losses,losses,margin:revenue>0?profit/revenue*100:null};
}
export const todayCO=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Bogota',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export function csvCell(value){let s=String(value??'');if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'}
