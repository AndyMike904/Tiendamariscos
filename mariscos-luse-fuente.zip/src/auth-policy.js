export function canAccess(roles,area){
 return ['admin','tech'].includes(area)&&Array.isArray(roles)&&roles.some(r=>r.role===area&&r.active===true);
}
