import {createClient} from '@supabase/supabase-js';
import {isRecoveryFragment} from './auth-recovery';
export const recoveryLink=isRecoveryFragment(window.location.hash);
const url=import.meta.env.VITE_SUPABASE_URL;
const key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
// Solo clave publicable. Nunca usar service_role ni secret keys en VITE_*.
export const authConfigured=Boolean(url&&key);
export const supabase=authConfigured?createClient(url,key,{auth:{storage:window.sessionStorage,persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}):null;

