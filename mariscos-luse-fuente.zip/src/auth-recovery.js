export function recoveryFeedback(error){
 if(!error)return {message:'Si el correo tiene una cuenta, recibirás un enlace para recuperar tu contraseña. Revisa también spam.',wait:60};
 if(error.code==='over_email_send_rate_limit'||error.status===429)return {message:'Supabase alcanzó el límite temporal de correos. No se envió un nuevo enlace. Espera hasta una hora antes de volver a solicitarlo y revisa el último correo recibido.',wait:3600};
 return {message:'No fue posible solicitar el enlace. Revisa tu conexión o inténtalo más tarde.',wait:0};
}
export function isRecoveryFragment(hash){return new URLSearchParams(hash.replace(/^#/, '')).get('type')==='recovery'}
