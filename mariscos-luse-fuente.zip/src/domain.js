export const cop = n => new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(n);
export const products = [
['salmon','Salmón','Pescados',78000,'Filete, Lomo, Porciones','Chile','photo-1467003909585-2f8a72700288'],
['trucha','Trucha','Pescados',32000,'Entera, Filete','Colombia','photo-1510130387422-82bed34b37e9'],
['pargo','Pargo rojo','Pescados',42000,'Entero limpio, Filete','Pacífico colombiano','photo-1535399831218-d5bd36d1a6b3'],
['robalo','Róbalo','Pescados',48000,'Postas, Filete','Pacífico colombiano','photo-1510130387422-82bed34b37e9'],
['corvina','Corvina','Pescados',45000,'Filete, Postas','Pacífico colombiano','photo-1535399831218-d5bd36d1a6b3'],
['atun','Atún','Pescados',65000,'Lomo, Bloque','Pacífico colombiano','photo-1510130387422-82bed34b37e9'],
['camaron','Camarón tigre','Mariscos',62000,'Pelado, Con cáscara','Pacífico colombiano','photo-1625944525533-473f1a3d54e7'],
['langostino','Langostino','Mariscos',72000,'Mediano, Jumbo','Pacífico colombiano','photo-1565680018434-b513d5e5fd47'],
['pulpo','Pulpo','Moluscos',68000,'Entero, Tentáculos','Pacífico colombiano','photo-1544943910-4c1dc44aab44'],
['ostras','Ostras','Moluscos',8000,'Unidad','Pacífico colombiano','photo-1559737558-2f5a35f4523b']
].map(([id,name,category,price,presentations,origin,photo],i)=>({id,name,category,price,presentations:presentations.split(', '),origin,photo:`https://images.unsplash.com/${photo}?auto=format&fit=crop&w=640&q=75`,unit:id==='ostras'?'unidad':'kg',type:i%3===0?'Congelado':'Fresco',stock:20,description:'Una selección para disfrutar el sabor del mar. Producto de prueba: origen, disponibilidad y precio por confirmar.',allergens:category==='Pescados'?'Pescado':category==='Moluscos'?'Moluscos':'Crustáceos'}));
export function total(items){return items.reduce((s,i)=>s+Math.round(i.price*i.quantity),0)}
export function message(order){return `Hola, soy ${order.name}. Pedido de prueba #${order.number}:\n${order.items.map(i=>`${i.name} · ${i.presentation} · ${i.quantity} ${i.unit}: ${cop(i.price*i.quantity)}${i.note?' · '+i.note:''}`).join('\n')}\nEntrega: ${order.delivery} · ${order.date} · ${order.slot}\n${order.address||'Retiro: dirección pendiente de confirmar'}\nTotal estimado de productos: ${cop(total(order.items))}. Domicilio y valor final se confirman por este chat al pesar. Pago por acordar.`}
